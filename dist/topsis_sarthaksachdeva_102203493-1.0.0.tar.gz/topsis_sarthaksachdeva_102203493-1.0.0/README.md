# Topsis-SarthakSachdeva-102203493
A Python package to implement the TOPSIS method for multi-criteria decision-making.

## Installation
```bash
pip install Topsis-SarthakSachdeva-102203493


##Usage
from topsis import topsis

topsis("input.csv", "1,1,1,2", "+,+,-,+", "output.csv")

License
This project is licensed under the MIT License.
